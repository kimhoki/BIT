//ex12-03.c
#include <stdio.h>
#include <string.h>
void main ( )
{
	char arr[10]={'A','B','C','D','E','F','G','H','I','J'};
	char temp[10];
	
	int i;

	memcpy(temp, arr, sizeof(char)*10);
	for( i = 0 ; i < 10 ; i++)
		printf("%c %c\n", arr[i], temp[i]);
	puts("=============");
	memcpy(temp, arr+5, sizeof(char)*5);
	memcpy(temp+5, arr, sizeof(char)*5);
	for( i = 0 ; i < 10 ; i++)
		printf("%c %c\n", arr[i], temp[i]);
}
