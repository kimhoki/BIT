//ex11-33.c
#include <stdio.h>
void main ( )
{
	int i, n = 0;

	for( i = 0 ; i < 30 ; i++)
	{
		printf("%2d", n);
		n = (n+1) % 5;
	}
	puts("");
	for( i = 0 ; i < 30 ; i++)
	{
		printf("%2d", n);
		n = (n+1) % 3;
	}
	puts("");
}
