//ex03-07.c
#include <stdio.h>
void main ( )
{
	char carr[5] = {'A', 'B', 'C', 'D', 'E'};

	printf("%x %x %x %x %x\n", 
		carr, carr+1, carr+2, carr+3, carr+4);
}

