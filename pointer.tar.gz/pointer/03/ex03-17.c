//ex03-17.c
#include <stdio.h>
void main ( )
{
	int iarr2[3][3] = {1,2,3,4,5,6,7,8,9};

	printf("%x\n", iarr2); //12ff5c
	printf("%x %x %x\n", iarr2[0], iarr2[1], iarr2[2]);
}
