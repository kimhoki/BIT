//ex03-20.c
#include <stdio.h>
void main ( )
{
	char carr2[2][2] = {'A','B','C','D'};

	printf("%x %x %x\n", carr2, *carr2, **carr2);
	printf("%x %x %x\n", carr2, carr2[0], carr2[0][0]);
}
