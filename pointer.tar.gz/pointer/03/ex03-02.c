//ex03-02.c
#include <stdio.h>
void main ( )
{
	int iarr[5]={1,2,3,4,5};

	printf("%x %x\n", iarr, &iarr[0]);
}
