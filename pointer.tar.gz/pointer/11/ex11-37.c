//ex11-37.c
#include <stdio.h>
void main ( )
{
	int n1= 0, n2 = 0;

	n2 = ++n1;
	printf("%d , %d\n", n1, n2);
}
