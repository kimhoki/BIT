//ex08-32.c
#include <stdio.h>
char* func( )
{
	static char carr[100];

	gets( carr );
	return carr;
}
void main( )
{
	char *str;

	str = func( );
	puts(str);
}
