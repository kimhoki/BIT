//ex14-05.c
#include <stdio.h>
typedef struct _sData
{
	char *str1;
	char *str2;
} DATA, *PDATA;
void main ( )
{
	DATA data1={"abc","ABC"}, data2={"def","DEF"};

	printf("%s %s\n", data1.str1, data1.str2);
	printf("%s %s\n", data2.str1, data2.str2);

	gets(data1.str1);// ��� �޸� ����
	gets(data1.str2);// ��� �޸� ����
	printf("%s %s\n", data1.str1, data1.str2);
}

