//ex09-01.c
#include <stdio.h>
void main ( )
{
	char c= 'A';
	int n = 10;
	void *vp;

	vp = &c;
	printf("%x %x\n", &c, vp);

	vp = &n;
	printf("%x %x\n", &n, vp);
}

