//ex08-19.c
#include <stdio.h>
void func(int *ip)
{
	printf("%x %d\n", ip, *ip);
}
void main ( )
{
	int n = 10;

	func( &n );
}
