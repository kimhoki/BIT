//ex01-03.c
#include <stdio.h>
void main ( )
{
	double d = 100;

	printf("%d\n", sizeof(d));
	printf("%g\n", d);
}