//ex08-11.c
#include <stdio.h>
void main ( )
{
	double div;

	div = 5.0 / 2.0;
	printf("%g\n", div);
	div = 10.0 / 3.0;
	printf("%g\n", div);
	div = 15.0 / 2.0;
	printf("%g\n", div);
}

