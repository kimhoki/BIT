//ex12-22.c
#include <stdio.h>
void main ( )
{
	char carr[2][3]={{'A','B','C'}, {'1','2','3'}};

	printf("%x %x %x\n", carr, carr[0], &carr[0][0]);
	printf("%x %x %x\n", carr+1, carr[0]+1, &carr[0][0]+1);
	printf("%x %x\n", &carr, &carr+1);
}

