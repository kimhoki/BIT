//ex11-38.c
#include <stdio.h>
void main( )
{
	int n1 = 1, n2 = 0;

	if(n1++ || n2++)
		puts("��");
	else
		puts("����");
	printf("%d %d\n", n1, n2);
}
