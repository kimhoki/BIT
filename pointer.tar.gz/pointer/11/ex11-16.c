//ex11-16.c
#include <stdio.h>
void main ( )
{
	int n1 = 5, n2 = 2;
	double d;

	d = n1 / n2;

	printf("%lf", d);
}
