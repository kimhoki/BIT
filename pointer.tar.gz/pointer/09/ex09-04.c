//ex09-04.c
#include <stdio.h>
void main ( )
{
	printf("%x\n", main );
}
