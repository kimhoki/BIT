//ex08-02.c
#include <stdio.h>
void func( )
{
	printf("1234567890\n"); 
}
void main ( )
{
	func( );
	func( );
	func( );
}

