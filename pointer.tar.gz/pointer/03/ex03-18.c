//ex03-18.c
#include <stdio.h>
void main ( )
{
	char carr2[2][2] = {'A','B','C','D'};

	printf("%x %x %x %x\n", 
		&carr2[0][0], carr2, carr2[0], carr2[1]);
}
