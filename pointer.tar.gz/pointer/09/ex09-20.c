//ex09-20.c
#include <stdio.h>
int function1( )
{
	puts("�Լ� 1�Դϴ�.");
	return 1;
}
int function2( )
{
	puts("�Լ� 2�Դϴ�.");
	return 2;
}
void main ( )
{
	int (*func[2])( );

	func[0] = function1;
	printf("%d\n", func[0]( ) );
	func[1] = function2;
	printf("%d\n", func[1]( ) );
}

