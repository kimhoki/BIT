//ex08-04.c
#include <stdio.h>
void func(int n)
{
	printf("%d\n", n);
}
void main( )
{
	func( 1 );
	func( 2 );
	func( 3 );
	func( 4 );
	func( 5 );
}
