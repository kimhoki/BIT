//ex07-11.c
#include <stdio.h>
struct _pData
{
	int *ip;
	int **ipp;
};
void main( )
{
	int n = 10;
	struct _pData s1;

	s1.ip = &n;
	s1.ipp = &s1.ip;

	printf("%d %d\n", *s1.ip, **s1.ipp);
	printf("%x %x\n", s1.ip, *s1.ipp);
	printf("%x %x\n", &s1.ip, s1.ipp);
	printf("%x %x %x\n", &s1, &s1.ip, &s1.ipp);
}

