//ex08-40.c
#include <stdio.h>
void b()
{
    printf("b() �Լ� \n");
}
void a( )
{
    b();
    printf("a() �Լ� \n");
}

void main( )
{
    a( );
    printf("main() �Լ�\n");
}