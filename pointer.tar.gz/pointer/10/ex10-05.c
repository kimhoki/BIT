//ex10-05.c
#include <stdio.h>
#include <stdlib.h>
void main ( )
{
	int *ip;

	ip = (int*) malloc(sizeof(int)*5);
	
	ip[0]=10; ip[1]=20; ip[2]=30; ip[3]=40; ip[4]=50;

	printf("%d %d %d %d %d\n", 
		ip[0], ip[1], ip[2], ip[3], ip[4]);
	free(ip);
}
