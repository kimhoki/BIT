//ex03-03.c
#include <stdio.h>
void main ( )
{
	char carr[5]={1,2,3,4,5};
	int iarr[5]={1,2,3,4,5};

	printf("%d %d\n", sizeof(carr), sizeof(iarr));
}

