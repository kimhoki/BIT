//ex14-09.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
typedef struct _person
{
	char *name;
	char *phone;
	int age;
} PERSON, *PPERSON;
void menu()
{
	puts("");
	puts("1. ��ȭ��ȣ ���");
	puts("2. ��ȭ��ȣ ����");
	puts("3. ��ȭ��ȣ ���");
	puts("4. ��ȭ��ȣ ����");
	puts("5. ����");	
	puts("================");	
}
char * InputStr( )
{
	char temp[100];
	char *str;

	gets(temp);
	str =(char*)malloc(sizeof(char)*strlen(temp)+1);
	strcpy(str,temp);

	return str;
}
PPERSON InputPerson( )
{
	PPERSON p = (PPERSON)malloc(sizeof(PERSON));

	fflush(stdin);
	printf("�̸��� �Է��ϼ���: ");
	p->name = InputStr();

	printf("��ȭ��ȣ�� �Է��ϼ���: ");
	p->phone = InputStr();

	printf("���̸� �Է��ϼ���: ");
	scanf("%d", &p->age);

	return p;
}
void Freememory(PPERSON p)
{
	free(p->name);
	free(p->phone);
	free(p);
}
void Remove(PPERSON strArray[], int *sCount)
{
	char name[100];
	int i;

	if( *sCount == 0)
		return;

	printf("�̸��� �Է��ϼ���:");
	gets(name);
	for( i = 0 ; i < *sCount ; i++)
	{
		if( strcmp(strArray[i]->name, name) == 0)
		{
			Freememory(strArray[i]);
			--*sCount;
			for( ; i < *sCount ; i++)
				strArray[i] = strArray[i+1];
			break;
		}
	}
}
void Output(PPERSON perArray[], int sCount)
{
	int i;
	for( i = 0 ; i < sCount ; i++)
		printf("[%d] : %s, %s, %d\n", i, 
			perArray[i]->name, perArray[i]->phone, perArray[i]->age);
}
void swap(PPERSON *a, PPERSON *b)
{
	PPERSON temp = *a;
	*a = *b;
	*b = temp;
}
void Sort(PPERSON perArray[], int sCount)
{
	int i, j, min;

	for( i = 0 ; i < sCount-1 ; i++)
	{
		for( min = i, j = i+1 ; j < sCount ; j++)
		{
			if( strcmp(perArray[j]->name, perArray[min]->name) < 0)
				min = j;
		}
		swap(&perArray[i], &perArray[min]);
	}
}
void main ( )
{
	PPERSON personArray[100];
	int sCount = 0, bContinue = 1;
	
	while(bContinue)
	{
		menu();
		switch(getch())
		{
		case '1':
			if(sCount < 100)
				personArray[sCount++] = InputPerson( );
			break;
		case '2':
			Remove(personArray, &sCount);
			break;
		case '3':
			Output(personArray, sCount);
			break;
		case '4':
			Sort(personArray, sCount);
			break;
		case 53:
			bContinue = !bContinue;
			break;
		default:
			puts("1~5���� �Է� �����մϴ�.");
		}
	}
}

