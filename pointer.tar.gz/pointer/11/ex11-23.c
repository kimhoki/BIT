//ex11-23.c
#include <stdio.h>
#include <stdlib.h>
void main ( )
{
	int i;
	for( i = 0 ; i < 10 ; i++)
		printf("%d\n", rand());
}
