//ex11-45.c
#include <stdio.h>
void swap(int *a, int *b)
{
	*a ^= *b;
	*b ^= *a;
	*a ^= *b;
}
void main ( )
{
	int a = 10, b = 20;

	printf("a = %d\n", a);
	printf("b = %d\n", b);

	swap(&a, &b);
	puts("=========");	
	printf("a = %d\n", a);
	printf("b = %d\n", b);
}

#include <stdio.h>
#define SWAP(a, b) {a^=b; b^=a; a^=b;}
void main ( )
{
	int a = 10, b = 20;

	printf("a = %d\n", a);
	printf("b = %d\n", b);

	SWAP(a,b);
	puts("=========");	
	printf("a = %d\n", a);
	printf("b = %d\n", b);
}
