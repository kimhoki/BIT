//ex03-10.c
#include <stdio.h>
void main( )
{
	int iarr[5] ={10, 20, 30, 40, 50};

	printf("%x %x %x %x %x\n", 
		iarr, iarr+1, iarr+2, iarr+3, iarr+4);
}
