//ex08-10.c
#include <stdio.h>
int func(int n1, int n2)
{
	return n1+n2;
}
void main ( )
{
	int sum;

	sum = func(5, 10);
	printf("%d\n", sum);
	sum = func(10, 20);
	printf("%d\n", sum);
	sum = func(20, 30);
	printf("%d\n", sum);
}
