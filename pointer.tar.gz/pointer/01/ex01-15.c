//ex01-15.c
#include <stdio.h>
void main ( )
{
	int n = 100;

	printf("%x\n", &n); //12ff7c
	printf("%d %d\n", n, *&n);
}
