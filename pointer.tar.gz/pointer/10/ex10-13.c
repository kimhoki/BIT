//ex10-13.c
#include <stdio.h>
#include <stdarg.h>
void minprintf(char *fmt, ... )
{
	int i;
	va_list ap;

	va_start(ap, fmt);

	for( i = 0; fmt[i] ; i++)
	{
		if( fmt[i] != '%')
			putchar(fmt[i]);
		else
			switch(fmt[++i])
			{
			case 'c':
				printf("%c", va_arg(ap,char));
				break;
			case 'd':
				printf("%d", va_arg(ap,int));
				break;
			case 's':
				printf("%s", va_arg(ap,char*));
				break;
			default:
				puts("�ڷ����� �߸� �Է� �ϼ̽��ϴ�.");
			}
	}
	va_end( ap );
}
void main ( )
{
	char c = 'A';
	char *str = "ABC";
	int a =10, b =20;

	minprintf("%d + %d = %d\n", a, b, a+b);
	minprintf("%s = ABC\n", str);
	minprintf("%c%c%c\n", c, c, c);
}
