//ex06-01.c
#include <stdio.h>
struct _point
{
	int x;
	int y;
};
void main ( )
{
	int		n1 = 10;
	struct _point 	p1 ={10,10};
}
