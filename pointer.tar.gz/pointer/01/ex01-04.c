//ex01-04.c
#include <stdio.h>
void main ( )
{
	char c = 'A';

	printf("%c\n", c);
	printf("%d %x\n", &c, &c);
}