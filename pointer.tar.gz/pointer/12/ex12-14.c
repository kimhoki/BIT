//ex12-14.c
#include <stdio.h>
#include <string.h>
void main ( )
{
	char *str1 = "ABCDEFGHI";
	char *str2 = "AB12EFG3I";
	int i;

	for(i = 0 ; i < 10 ; i+=2)
	{
		if( memcmp(str1 + i, str2 + i, 2 ) == 0)
			puts("TRUE");
		else
			puts("FALSE");
	}
}
