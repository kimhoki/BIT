//ex10-06.c
#include <stdio.h>
#include <stdlib.h>
void main ( )
{
	int (*arr)[3];

	arr = (int (*)[3])malloc(sizeof(int)*3*3);

	arr[0][0]=10; arr[0][1]=20; arr[0][2]=30;
	arr[1][0]=40; arr[1][1]=50; arr[1][2]=60;
	arr[2][0]=70; arr[2][1]=80; arr[2][2]=90;

	printf("%d %d %d\n", arr[0][0],arr[0][1],arr[0][2]);
	printf("%d %d %d\n", arr[1][0],arr[1][1],arr[1][2]);
	printf("%d %d %d\n", arr[2][0],arr[2][1],arr[2][2]);

	free( arr );
}
