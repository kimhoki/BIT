//ex10-03.c
#include <stdio.h>
#include <stdlib.h>
void main ( )
{
	char *cp;

	cp = (char*) malloc(sizeof(char));
	*cp = 'A';

	printf("%c\n", *cp);
	free( cp );
}
void main ( )
{
	int *ip;

	ip = (int*) malloc(sizeof(int));
	*ip = 500;

	printf("%d\n", *ip);
	free( ip );
}
