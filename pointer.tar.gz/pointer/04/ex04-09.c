//ex04-09.c
#include <stdio.h>
void main ( )
{
	char carr[4]={'A','B','C','D'};

	printf("%c %c %c %c\n",carr[0], carr[1], carr[2], carr[3]);
}

