//ex12-16.c
#include <stdio.h>
void main ( )
{
	int arr[5] = {10,20,30,40,50};
	int *ap = arr;
	int i;

	for( i = 0 ; i < 5; i++)
		printf("%d\n", *ap++);
	puts("============");
	printf("%x %x\n",arr, ap);
}
