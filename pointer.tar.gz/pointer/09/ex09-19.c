//ex09-19.c
#include <stdio.h>
int function1( )
{
	puts("�Լ� 1�Դϴ�.");
	return 1;
}
int function2( )
{
	puts("�Լ� 2�Դϴ�.");
	return 2;
}
void main ( )
{
	int (*func)( );

	func = function1;
	printf("%d\n", func( ) );
	func = function2;
	printf("%d\n", func( ) );
}
