//ex08-37.c
#include <stdio.h>
int func( )
{
	int m = 10;

	return 10;
}
void main ( ) 
{
	int n;

	n = func( );

	printf("%d\n", n);
}
