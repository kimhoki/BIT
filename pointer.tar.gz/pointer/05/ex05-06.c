//ex05-06.c
#include <stdio.h>
void main ( )
{
	char *str = "ABCDEFG";

	puts(str);
	puts(str+1);
	puts(str+2);
	puts(str+3);
}
