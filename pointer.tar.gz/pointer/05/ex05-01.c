//ex05-01.c
#include <stdio.h>
void main ( )
{
	char *cp = "ABCD";

	printf("%c%c%c%c%c\n",cp[0], cp[1], cp[2], cp[3], cp[4]);
	printf("%d %d %d %d %d\n",cp[0], cp[1], cp[2], cp[3], cp[4]);
}
