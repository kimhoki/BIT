//ex08-01.c
#include <stdio.h>
void main ( )
{
	printf("1234567890\n"); 
	printf("1234567890\n"); 
	printf("1234567890\n"); 
}

