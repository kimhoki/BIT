//ex15-02.c
#include <stdio.h>
#define STACKSIZE 10
#define ERROR_VALUE 0xfffffff
void Push(int Stack[], int *top, int data)
{
	if( *top == STACKSIZE)
	{
		puts("���̻� �ڷḦ ���� �� �� �����ϴ�.");
		return;
	}

	Stack[(*top)++] = data;
}
int Pop(int Stack[], int *top )
{
	if( *top == 0 )
	{
		puts("�ڷᰡ �����ϴ�.");
		return ERROR_VALUE;
	}
	return Stack[--*top];
}
void main( )
{
	int Stack[STACKSIZE];
	int top = 0;

	Push(Stack, &top, 100);
	Push(Stack, &top, 200);
	Push(Stack, &top, 300);

	printf("%d\n", Pop(Stack, &top));
	printf("%d\n", Pop(Stack, &top));
	printf("%d\n", Pop(Stack, &top));
}

