//ex11-25.c
#include <stdio.h>
#include <stdlib.h>
void main ( )
{
	int i;
	srand( (unsigned) time(NULL));
	for( i = 0 ; i < 10 ; i++)
		printf("%d\n", rand());
}
