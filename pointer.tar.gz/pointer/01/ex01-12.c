//ex01-12.c
#include <stdio.h>
void main ( )
{
	char c = 5;
	int n;

	n = (int) c;
	printf("%d\n", n);
}
