//ex08-25.c
#include <stdio.h>
void func( char *s)
{
	puts( s );
}
void main ( )
{
	func( "ABCD" );
}
