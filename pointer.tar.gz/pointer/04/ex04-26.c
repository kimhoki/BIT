//ex04-26.c
#include <stdio.h>
void main ( )
{
	int a = 10, b = 20, c = 30, d = 40, e = 50;
	int *iarr[5] ={&a, &b, &c, &d, &e};

	printf("%x %x %x %x %x\n", &a, &b, &c, &d, &e);
	printf("%x %x %x %x %x\n", 
		iarr[0], iarr[1], iarr[2], iarr[3], iarr[4]);

	printf("%d %d %d %d %d\n", a, b, c, d, e);
	printf("%d %d %d %d %d\n", 
		*iarr[0], *iarr[1], *iarr[2], *iarr[3], *iarr[4]);
}
