//ex13-17.c
#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <conio.h>
char AlphaRand( )
{
	return rand()%26+'A';
}
void StrRand(int n)
{
	char temp[20]={0};

	int i;
	for( i = 0 ; i < n ;i++)
		temp[i] = AlphaRand( );
	puts(temp);
}
void main ( )
{
	int c;

	srand((unsigned)time(NULL));
	while(1)
	{
		c = getch();
		if( '1' <= c && c <= '9')
			StrRand( c - '0');
		else
			break;
	}
}

