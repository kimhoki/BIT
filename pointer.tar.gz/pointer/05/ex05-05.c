//ex05-05.c
#include <stdio.h>
void main ( )
{
	char *str = "ABCDEFG";

	printf("%s\n", str);
	printf("%s\n", str+1);
	printf("%s\n", str+2);
	printf("%s\n", str+3);
}
