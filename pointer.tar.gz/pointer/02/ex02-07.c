//ex02-07.c
#include <stdio.h>
void main ( )
{
   int n = 20;
   int *np;
   int **npp;
   int ***nppp;

   np = &n;
   npp = &np;
   nppp = &npp;

   printf("%d %d %d %d\n",n, *np, **npp, ***nppp);
   printf("%x %x %x %x\n",&n, np, *npp, **nppp);
   printf("%x %x %x \n", &np, npp, *npp);
   printf("%d %d %d %d\n", sizeof(int), sizeof(int*), sizeof(int**), sizeof(int***));
   printf("%d %d %d %d\n", sizeof(n), sizeof(np), sizeof(npp), sizeof(nppp));
}
