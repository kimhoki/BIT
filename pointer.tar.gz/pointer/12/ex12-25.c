//ex12-25.c
#include <stdio.h>
#include <string.h>
void main ( )
{
	int arr1[25];
	int arr2[5][5];
	int i, j;
	
	for(i = 0 ; i < 25 ; i++)
		arr1[i] = (i+1)*10;
	memcpy(arr2, arr1, sizeof(int)*25);

	for(i = 0 ; i < 5 ; i++)
		arr1[i*5+i] = 0;
	for(i = 0 ; i < 25 ; i++)
	{
		printf("%5d", arr1[i]);
		if( (i+1) % 5 == 0)
			puts("");
	}

	puts("=========================");
	for( i = 0 ; i < 5 ; i++)
		arr2[i][i] = 0;
	for( i = 0 ; i < 5 ; i++)
	{
		for( j = 0 ; j < 5; j++)
			printf("%5d", arr2[i][j]);
		puts("");
	}
}

