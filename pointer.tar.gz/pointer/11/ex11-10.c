//ex11-10.c
#include <stdio.h>
void main ( )
{
	char temp[20];

	printf("���ڿ� �Է�:");
	fgets(temp, 20, stdin);
	fputs(temp, stdout);
}
