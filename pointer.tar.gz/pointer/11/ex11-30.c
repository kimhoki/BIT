//ex11-30.c
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
void main ( )
{
	int i;
	int arr[100];

	srand( (unsigned) time(NULL));
	for( i = 0 ; i < 100 ; i++)
	{
		arr[i] = rand() % 100;
	}
	for( i = 0 ; i < 100 ; i++)
	{
		if( (i+1) % 10 == 0 )
			puts("");
		else
			printf("%3d", arr[i]);
	}
}
