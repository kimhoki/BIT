//ex13-20.c
#include <locale.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
void menu()
{
	_putws(L"");
	_putws(L"1. ���ڿ� �Է�");
	_putws(L"2. ���ڿ� ����");
	_putws(L"3. ���ڿ� ���");
	_putws(L"4. ���ڿ� ����");
	_putws(L"5. ����");	
	_putws(L"================");	
}
wchar_t * Input( )
{
	wchar_t temp[100];
	wchar_t *str;
	wprintf(L"100�� ������ ���ڸ� �Է��ϼ���: ");
	_getws(temp);
	str =(wchar_t*)malloc(sizeof(wchar_t)*wcslen(temp)+sizeof(wchar_t));
	wcscpy(str,temp);

	return str;
}
void Remove(wchar_t *strArray[], int *sCount)
{
	wchar_t temp[100];
	int i;

	if( *sCount == 0)
		return;

	wprintf(L"������ ���ڿ��� �Է��ϼ���:");
	_getws(temp);
	for( i = 0 ; i < *sCount ; i++)
	{
		if( wcscmp(strArray[i], temp) == 0)
		{
			free(strArray[i]);
			--*sCount;
			for( ; i < *sCount ; i++)
				strArray[i] = strArray[i+1];
			break;
		}
	}

}
void Output(wchar_t *strArray[], int sCount)
{
	int i;
	for( i = 0 ; i < sCount ; i++)
		wprintf(L"%d : %s\n", i, strArray[i]);
}
void swap(wchar_t **a, wchar_t **b)
{
	wchar_t *temp = *a;
	*a = *b;
	*b = temp;
}
void Sort(wchar_t *strArray[], int sCount)
{
	int i, j, min;

	for( i = 0 ; i < sCount-1 ; i++)
	{
		for( min = i, j = i+1 ; j < sCount ; j++)
		{
			if( wcscmp(strArray[j], strArray[min]) < 0)
				min = j;
		}
		swap(&strArray[i], &strArray[min]);
	}
}
void main ( )
{
	wchar_t *strArray[100];
	int sCount = 0, bContinue = 1;

    _wsetlocale(LC_ALL, L"Korean");

 	while(bContinue)
	{
		menu();
		switch(_getwch())
		{
		case L'1':
			if(sCount < 100)
				strArray[sCount++] = Input( );
			break;
		case L'2':
			Remove(strArray, &sCount);
			break;
		case L'3':
			Output(strArray, sCount);
			break;
		case L'4':
			Sort(strArray, sCount);
			break;
		case 53:
			bContinue = !bContinue;
			break;
		default:
			puts("1~5���� �Է� �����մϴ�.");
		}
	}
}

