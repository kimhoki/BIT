//ex07-10.c
#include <stdio.h>
struct _string
{
	char *str1;
	char str2[8];
};
void main ( )
{
	struct _string s1={"ABC","ABC"};

	printf("%s %s\n", s1.str1, s1.str2);
	printf("%d %d %d\n", sizeof(s1), sizeof(s1.str1), sizeof(s1.str2));
}
