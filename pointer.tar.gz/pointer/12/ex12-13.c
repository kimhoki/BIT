//ex12-13.c
#include <stdio.h>
#include <string.h>
void main ( )
{
	char *str1 = "ABCDEFGHI";
	char *str2 = "AB12EFG3I";
	int i;

	for(i = 0 ; str1[i] ; i++)// str1[i] != '\0';
	{
		if( memcmp(str1 + i, str2 + i, 1 ) == 0)
			puts("TRUE");
		else
			puts("FALSE");
	}
}
