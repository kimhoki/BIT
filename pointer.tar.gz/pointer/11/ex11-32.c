//ex11-32.c
#include <stdio.h>
#include <stdlib.h>
void main ( )
{
	char arr[100];
	int numCount[26] = {0};
	int i;

	for( i = 0 ; i < 100 ; i++)
	{
		arr[i] = rand() % 26 + 'A';
	}
	for( i = 0 ; i < 100 ; i++)
	{
		if( (i+1) % 10 == 0 )
			puts("");
		else
			printf("%2c", arr[i]);
	}
	//////////////////////////////////
	puts("===========================");
	for( i = 0 ; i < 100 ; i++)
	{
		numCount[arr[i]-'A']++;
	}
	for( i = 0 ; i < 26 ; i++)
	{
		printf("%c�� ���ڴ� %d�� �Դϴ�.\n",
			i+'A', numCount[i]);
	}
}
