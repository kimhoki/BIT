//ex03-08.c
#include <stdio.h>
void main ( )
{
	char carr[5] = {'A', 'B', 'C', 'D', 'E'};

	printf("%c %c %c %c %c\n", 
		*(char*)0x12ff78, *(char*)0x12ff79, *(char*)0x12ff7a,
		*(char*)0x12ff7b, *(char*)0x12ff7c);
}
