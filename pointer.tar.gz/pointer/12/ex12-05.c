//ex12-05.c
#include <stdio.h>
#include <string.h>
void main ( )
{
	int n = 0x44434241;
	char c;
	int i;

	for( i = 0 ; i < 4 ; i++)
	{
		memcpy(&c, (char*)&n+i , sizeof(char));
		printf("%c %x\n", c, c);
	}
}
