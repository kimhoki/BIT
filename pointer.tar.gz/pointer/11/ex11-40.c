//ex11-40.c
#include <stdio.h>
void main( )
{
	int n1 = 0, n2 = 0;

	if(n1++ && n2++)
		puts("��");
	else
		puts("����");
	printf("%d %d\n", n1, n2);
}
