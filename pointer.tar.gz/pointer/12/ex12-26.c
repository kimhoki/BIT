//ex12-26.c
#include <stdio.h>
void main ( )
{
	int arr[25];
	int (*ap)[5] = (int (*)[5])arr;
	int i,j;
	
	for(i = 0 ; i < 25 ; i++)
		arr[i] = (i+1)*10;

	for( i = 0 ; i < 5 ; i++)
		ap[i][i] = 0;
	for( i = 0 ; i < 5 ; i++)
	{
		for( j = 0 ; j < 5; j++)
			printf("%5d", ap[i][j]);
		puts("");
	}

	puts("=========================");
	for(i = 0 ; i < 25 ; i++)
	{
		printf("%5d", arr[i]);
		if( (i+1) % 5 == 0)
			puts("");
	}
}

