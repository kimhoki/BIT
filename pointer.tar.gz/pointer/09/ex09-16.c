//ex09-16.c
#include <stdio.h>
void main ( )
{
	int iarr1[2][3]={{21,22,23},{24,25,26}};
	int iarr2[3][3]={{31,32,33},{34,35,36},{37,38,39}};
	int (*arr[2])[3];

	arr[0] = iarr1;
	arr[1] = iarr2;

	printf("%d %d %d\n", arr[0][0][0],arr[0][0][1],arr[0][0][2]);
	printf("%d %d %d\n", arr[0][1][0],arr[0][1][1],arr[0][1][2]);
	puts("===========");
	printf("%d %d %d\n", arr[1][0][0],arr[1][0][1],arr[1][0][2]);
	printf("%d %d %d\n", arr[1][1][0],arr[1][1][1],arr[1][1][2]);
	printf("%d %d %d\n", arr[1][2][0],arr[1][2][1],arr[1][2][2]);
}
