//ex11-05.c
#include <stdio.h>
void main ( )
{
	int c;
	while((c = getchar()) != '\n')
		putchar(c);
}
