//ex12-21.c
#include <stdio.h>
void main ( )
{
	int arr[5] = {10,20,30,40,50};

	printf("%x %x\n", &arr[0], &arr[2]);
	printf("%d\n", &arr[2] - &arr[0]);
	printf("%d\n", &arr[0] - &arr[2]);
	printf("%x %x\n", &arr[5], &arr[0]);
	printf("%d\n", &arr[5] - &arr[0]);
	printf("%d\n", &arr[0] - &arr[5]);
}

