//ex11-27.c
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
void main ( )
{
	int i;

	srand( (unsigned) time(NULL));
	for( i = 0 ; i < 10 ; i++)
		printf("%d ", rand() % 10);
}
