//ex14-14.c
#include <stdio.h>
#include <string.h>
#include <conio.h>
typedef struct _bitfield
{
	unsigned D:8;
	unsigned C:8;
	unsigned B:8;
	unsigned A:8;
} BITFIELD;
void main ( )
{
	BITFIELD bit;
	int bContinue = 1;

	memset(&bit, 0, sizeof(BITFIELD));

	while(bContinue)
	{
		printf("%08X\n", bit);
		switch(getch())
		{
		case 'a': case 'A':
			bit.A ^=0xFF;
			break;
		case 'b': case 'B':
			bit.B ^=0xFF;
			break;
		case 'c': case 'C':
			bit.C ^=0xFF;
			break;
		case 'd': case 'D':
			bit.D ^=0xFF;
			break;
		default:
			bContinue = 0;
		}
	}
}

