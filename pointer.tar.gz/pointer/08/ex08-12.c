//ex08-12.c
#include <stdio.h>
double func(double d1, double d2)
{
	return d1/d2;
}
void main ( )
{
	double div;

	div = func(5.0, 2.0);
	printf("%g\n", div);
	div = func(10.0, 3.0);
	printf("%g\n", div);
	div = func(15.0, 2.0);
	printf("%g\n", div);
}

