//ex03-01.c
#include <stdio.h>
void main ( )
{
	char carr[5]={1,2,3,4,5};

	printf("%x %x\n", carr, &carr[0]);
}
