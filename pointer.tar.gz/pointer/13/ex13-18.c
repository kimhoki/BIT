//ex13-18.c
#include <stdio.h>
#include <string.h>
void main ( )
{
	wchar_t *str1 = L"ABCDE";
	wchar_t str2[100];

	wcscpy(str2 , str1);
	wprintf(L"%s %s\n", str1, str2);
}