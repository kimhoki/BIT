//ex12-12.c
#include <stdio.h>
#include <string.h>
void main ( )
{
	int n1 = 0x2010, n2 = 0x40302010;
	int i;

	for(i = 0 ; i < 4 ; i++)
	{
		if( memcmp((char*)&n1+i, (char*)&n2+i, 1 ) == 0)
			puts("TRUE");
		else
			puts("FALSE");
	}
}
