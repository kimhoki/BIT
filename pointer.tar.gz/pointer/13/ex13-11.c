//ex13-11.c
#include <stdio.h>
#include <string.h>
void main ( )
{
	char *str1 = "ABCDE";
	char str2[100] = "ABCDE";

	if( str1 == str2 )
		puts("TRUE");
	else
		puts("FALSE");
	if( strcmp(str1,str2) ==0 )
		puts("TRUE");
	else
		puts("FALSE");
}

