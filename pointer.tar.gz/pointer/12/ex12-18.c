//ex12-18.c
#include <stdio.h>
void main ( )
{
	int arr[5] = {10,20,30,40,50};
	int *ap = arr;

	printf("%x %x\n", ap, arr);
	printf("%x %x\n", *ap, *arr);
	//printf("%x %x\n", *ap++, *arr++);
}
