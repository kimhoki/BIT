//ex08-29.c
#include <stdio.h>
int* func( )
{
	int n;
	scanf("%d", &n);

	return &n;
}
void main ( )
{
	int *ip;

	ip = func( );
	printf("%d\n", *ip);
}
