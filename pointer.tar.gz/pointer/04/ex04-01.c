//ex04-01.c
#include <stdio.h>
void main ( )
{
	char c = 'A';
	char *cp = &c;

	printf("%c %c %c\n", c, *cp, cp[0]);
}
