//ex09-15.c
#include <stdio.h>
void main ( )
{
	int arr3[2][2][3]={{{10,20,30},{40,50,60}},
			{{70,80,90},{100,110,120}}};
	int (*arr)[2][3];

	arr = arr3;

	printf("%d %d %d\n", arr[0][0][0],arr[0][0][1],arr[0][0][2]);
	printf("%d %d %d\n", arr[0][1][0],arr[0][1][1],arr[0][1][2]);
	printf("%d %d %d\n", arr[1][0][0],arr[1][0][1],arr[1][0][2]);
	printf("%d %d %d\n", arr[1][1][0],arr[1][1][1],arr[1][1][2]);
}

