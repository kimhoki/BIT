//ex05-02.c
#include <stdio.h>
void main ( )
{
	char carr[10] = "ABCD";

	printf("%c%c%c%c%c\n",carr[0], carr[1], carr[2], carr[3], carr[4]);
	printf("%d %d %d %d %d\n",carr[0], carr[1], carr[2], carr[3], carr[4]);
}
