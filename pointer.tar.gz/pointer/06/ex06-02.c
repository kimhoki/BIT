//ex06-02.c
#include <stdio.h>
struct _point
{
	int x;
	int y;
};

void main ( )
{
	int		n1 = 10;
	struct _point p1={10,10};

	printf("%d %d\n", sizeof(n1), sizeof(p1));
	printf("%d %d\n", sizeof(p1.x), sizeof(p1.y));

}
