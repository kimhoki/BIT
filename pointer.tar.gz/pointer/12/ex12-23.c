//ex12-23.c
#include <stdio.h>
void main ( )
{
	int iarr[2][3]={{10,20,30}, {100,200,300}};

	printf("%x %x %x\n", iarr, iarr[0], &iarr[0][0]);
	printf("%x %x %x\n", iarr+1, iarr[0]+1, &iarr[0][0]+1);
	printf("%x %x\n", &iarr, &iarr+1);
}

