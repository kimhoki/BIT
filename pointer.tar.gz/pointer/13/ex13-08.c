//ex13-08.c
#include <stdio.h>
#include <string.h>
void main ( )
{
	char *str = "ABCDE";

	printf("%d\n", strlen(str));
}

