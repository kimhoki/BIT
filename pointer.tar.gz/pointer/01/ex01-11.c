//ex01-11.c
#include <stdio.h>
void main ( )
{
	char c = 5;
	int n;

	n = c;
	printf("%d\n", n);
}
