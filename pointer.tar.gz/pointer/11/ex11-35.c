//ex11-35.c
#include <stdio.h>
void main ( )
{
	printf("&& : %d\n", 0 && 1);
	printf("&& : %d\n", 1 && 1);
	printf("&& : %d\n", 10 && 20);
	printf("&& : %d\n", 100 && 200);
	puts("==========");
	printf("|| : %d\n", 0 || 1);
	printf("|| : %d\n", 1 || 1);
	printf("|| : %d\n", 10 || 20);
	printf("|| : %d\n", 100 || 200);
	puts("==========");
	printf("! : %d\n", !0 );
	printf("! : %d\n", !1 );
	printf("! : %d\n", !100 );
	printf("! : %d\n", !-100 );
}
