//ex01-02.c
#include <stdio.h>
void main ( )
{
	int n = 100;

	printf("%d\n", sizeof(n));
	printf("%d\n", n);
}