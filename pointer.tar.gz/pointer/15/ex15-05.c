//ex15-05.c
#include <stdio.h>
#define QUEUESIZE 10
#define ERROR_VALUE 0xfffffff

int Queue[QUEUESIZE];
int front = 0, rear = 0;
void Add(int data)
{
	if((rear+1) % QUEUESIZE == front)
	{
		puts("���̻� �ڷḦ ���� �� �� �����ϴ�.");
		return ;
	}
	Queue[rear = (rear+1) % QUEUESIZE] = data;
}
int Delete( )
{
	if( front == rear )
	{
		puts("�ڷᰡ �����ϴ�.");
		return ERROR_VALUE;
	}
	return Queue[front = (front+1) % QUEUESIZE];
}
void main ( )
{
	Add( 10 );
	Add( 20 );
	Add( 30 );

	printf("%d\n", Delete( ));
	printf("%d\n", Delete( ));
	printf("%d\n", Delete( ));
}

