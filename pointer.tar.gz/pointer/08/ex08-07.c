//ex08-07.c
#include <stdio.h>
void main ( )
{
	printf("%c, %d, %g\n", 'A', 10, 10.123);
	printf("%c, %d, %g\n", 'B', 20, 20.123);
	printf("%c, %d, %g\n", 'C', 30, 30.123);
}
