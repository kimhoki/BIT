//ex08-05.c
#include <stdio.h>
void main ( )
{
	printf("(%d,%d)\n", 2, 2);
	printf("(%d,%d)\n", 2, 3);
	printf("(%d,%d)\n", 10, 20);
}

