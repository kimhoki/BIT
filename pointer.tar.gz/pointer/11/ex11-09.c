//ex11-09.c
#include <stdio.h>
void main ( )
{
	char temp[20];

	printf("���ڿ� �Է�:");
	gets(temp);
	puts(temp);
}

