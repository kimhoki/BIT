//ex08-20.c
#include <stdio.h>
void func(double *dp)
{
	printf("%x %g\n", dp, *dp);
}
void main ( )
{
	double d = 10.55;

	func( &d );
}
