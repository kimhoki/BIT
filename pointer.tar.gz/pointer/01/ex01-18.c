//ex01-18.c
#include <stdio.h>
void main ( )
{
	char c;

	c  = 321; //(0x141)

	printf("%x %c\n", c, c);
}
