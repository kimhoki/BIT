//ex08-08.c
#include <stdio.h>
void func(char c, int n, double d)
{
	printf("%c, %d, %g\n", c, n, d);
}
void main ( )
{
	func('A', 10, 10.123);
	func('B', 20, 20.123);
	func('C', 30, 30.123);
}
