//ex15-13.c
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
typedef struct _node
{
	int data;
	struct _node *link;
} DATA, *PDATA;
PDATA nodeAlloc(int data)
{
	PDATA p = (PDATA)malloc(sizeof(DATA));
	p->data = data;
	p->link = NULL;

	return p;
}
PDATA insertNode(PDATA head, int data)
{
	PDATA p = head, n = nodeAlloc( data );

	if( head == NULL)
		return n;
	while(p->link)
		p = p->link;
	p->link = n;

	return head;
}
PDATA deleteNode(PDATA head, int data)
{
	PDATA p = head, pp;
	while( p && p->data != data)
	{
		pp = p;
		p = p->link;
	}
	if( p == NULL)
		puts("�ڷᰡ �����ϴ�.");
	else if( p == head ) {
		head = p->link;
		free(p);
	}
	else {
		pp->link = p->link;
		free(p);
	}
	return head;
}
void printNode(PDATA p)
{
	int i;
	for(i=0 ; p ; p = p->link, i++)
		printf("%d ; [%d]\n", i, p->data);
}
void menu()
{
	puts("");
	puts("1. ���� �Է�");
	puts("2. ���� ����");
	puts("3. ���� ���");
	puts("4. ����");	
	puts("================");	
}
void Input(PDATA *nHead)
{
	*nHead = insertNode(*nHead, rand() % 1000);
	puts("���� �Է� �Ϸ�");
}
void Remove(PDATA *nHead)
{
	int n;
	
	printf("���� �� ������ �Է��ϼ���:");
	scanf("%d", &n);
	*nHead = deleteNode(*nHead, n);
}
void Output(PDATA nHead)
{
	printNode(nHead);
}
void main( )
{
	PDATA nHead = NULL;
	int bContinue = 1;
	
	while(bContinue)
	{
		menu();
		switch(getch())
		{
		case '1':
			Input(&nHead);
			break;
		case '2':
			Remove(&nHead);
			break;
		case '3':
			Output(nHead);
			break;
		case '4':
			bContinue = !bContinue;
			break;
		default:
			puts("1~4���� �Է� �����մϴ�.");
		}
	}
}

