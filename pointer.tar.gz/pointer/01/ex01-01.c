//ex01-01.c
#include <stdio.h>
void main ( )
{
	char c = 'A';

	printf("%d\n", sizeof(c));
	printf("%c\n", c);
}