//ex13-19.c
#include <stdio.h>
#include <string.h>
void main ( )
{
	wchar_t *str1 = L"ABCDE";
	wchar_t str2[100]=L"abc";

    wprintf(L"len:%d, %d\n", wcslen(str1), wcslen(str2));
    wprintf(L"str1 , str2: %d\n", wcscmp( str1, str2) );
	wcscat(str2 , str1);
	wprintf(L"%s %s\n", str1, str2);
}