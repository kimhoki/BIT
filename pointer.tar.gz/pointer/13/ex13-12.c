//ex13-12.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
void menu()
{
	puts("");
	puts("1. ���ڿ� �Է�");
	puts("2. ���ڿ� ����");
	puts("3. ���ڿ� ���");
	puts("4. ���ڿ� ����");
	puts("5. ����");	
	puts("================");	
}
char * Input( )
{
	char temp[100];
	char *str;
	printf("100�� ������ ���ڸ� �Է��ϼ���: ");
	gets(temp);
	str =(char*)malloc(sizeof(char)*strlen(temp)+1);
	strcpy(str,temp);

	return str;
}
void Remove(char *strArray[], int *sCount)
{
	char temp[100];
	int i;

	if( *sCount == 0)
		return;

	printf("������ ���ڿ��� �Է��ϼ���:");
	gets(temp);
	for( i = 0 ; i < *sCount ; i++)
	{
		if( strcmp(strArray[i], temp) == 0)
		{
			free(strArray[i]);
			--*sCount;
			for( ; i < *sCount ; i++)
				strArray[i] = strArray[i+1];
			break;
		}
	}

}
void Output(char *strArray[], int sCount)
{
	int i;
	for( i = 0 ; i < sCount ; i++)
		printf("%d : %s\n", i, strArray[i]);
}
void swap(char **a, char **b)
{
	char *temp = *a;
	*a = *b;
	*b = temp;
}
void Sort(char *strArray[], int sCount)
{
	int i, j, min;

	for( i = 0 ; i < sCount-1 ; i++)
	{
		for( min = i, j = i+1 ; j < sCount ; j++)
		{
			if( strcmp(strArray[j], strArray[min]) < 0)
				min = j;
		}
		swap(&strArray[i], &strArray[min]);
	}
}
void main ( )
{
	char *strArray[100];
	int sCount = 0, bContinue = 1;
	
	while(bContinue)
	{
		menu();
		switch(getch())
		{
		case '1':
			if(sCount < 100)
				strArray[sCount++] = Input( );
			break;
		case '2':
			Remove(strArray, &sCount);
			break;
		case '3':
			Output(strArray, sCount);
			break;
		case '4':
			Sort(strArray, sCount);
			break;
		case 53:
			bContinue = !bContinue;
			break;
		default:
			puts("1~5���� �Է� �����մϴ�.");
		}
	}
}

