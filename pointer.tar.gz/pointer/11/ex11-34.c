//ex11-34.c
#include <stdio.h>
void main ( )
{
	printf("== : %d\n", 10 == 20);
	printf("!= : %d\n", 10 != 20);
	printf("< : %d\n", 10 < 20);
	printf("> : %d\n", 10 > 20);
	printf("<= : %d\n", 10 <= 20);
	printf(">= : %d\n", 10 >= 20);
}
