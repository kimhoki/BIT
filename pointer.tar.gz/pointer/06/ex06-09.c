//ex06-09.c
#include <stdio.h>
union _data
{
	char carr[4];
	int n;
};
void main( )
{
	union _data u;
	u.n = 0x44434241;

	printf("%x %d\n", u.n, u.n);
	printf("%c %c %c %c\n", 
		u.carr[0], u.carr[1], u.carr[2], u.carr[3]); 
}
