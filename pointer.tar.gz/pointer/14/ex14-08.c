//ex14-08.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct _sData
{
	char *smallStr;
	char *largeStr;
} DATA, *PDATA;
char AlphaRandSmall( )
{
	return rand()%26+'a';
}
char AlphaRandLarge( )
{
	return rand()%26+'A';
}
char* StrRand(int type, int n)
{
	char temp[20]={0};
	char *str;
	int i;
	if( type == 1)//�ҹ���
	{
		for( i = 0 ; i < n ;i++)
			temp[i] = AlphaRandSmall( );
	}
	else if (type == 2)//�빮��
	{
		for( i = 0 ; i < n ;i++)
			temp[i] = AlphaRandLarge( );
	}
	else 
		return NULL;

	str = (char*)malloc(strlen(temp)+1);
	strcpy(str, temp);
	return str;
}
void main ( )
{
	DATA darr[10];
	int i;
	
	for( i = 0 ; i < 10 ; i++)
	{
		darr[i].smallStr = StrRand(1, rand()%5+6);
		darr[i].largeStr = StrRand(2, rand()%5+6);
	}
	for( i = 0 ; i < 10 ; i++)
		printf("%-20s %-20s\n", darr[i].smallStr, darr[i].largeStr);
	puts("===========================");
	for( i = 0 ; i < 10 ; i++)
		printf("%-20s %-20s\n", (darr+i)->smallStr, (darr+i)->largeStr);
	puts("===========================");
}

