//ex02-02.c
#include <stdio.h>
void main ( )
{
   int n = 20;
   int *np = &n;

   printf("%c %c\n", n, *np);
   printf("%d %d\n", sizeof(int), sizeof(int*));//4 4
   printf("%d %d\n", sizeof(n), sizeof(np));//4 4
}
