//ex12-04.c
#include <stdio.h>
#include <string.h>

void main ( )
{
	int arr[10]={1,2,3,4,5,6,7,8,9,10};
	int temp[10];
	int i;

	memcpy(temp, arr, sizeof(int)*10);
	for( i = 0 ; i < 10 ; i++)
		printf("%d %d\n", arr[i], temp[i]);
	puts("=============");
	memcpy(temp, arr+5, sizeof(int)*5);
	memcpy(temp+5, arr, sizeof(int)*5);
	for( i = 0 ; i < 10 ; i++)
		printf("%d %d\n", arr[i], temp[i]);
}
