//ex03-16.c
#include <stdio.h>
void main( )
{
	char carr2[2][3] = {'A','B','C','D','E','F'};

	printf("%x\n", carr2);// 12ff78
	printf("%x %x %x %x\n", 
		carr2[0], carr2[1], &carr2[0][0], &carr2[1][0]);
}
