//ex08-06.c
#include <stdio.h>
void func(int n1, int n2)
{
	printf("(%d,%d)\n", n1, n2);
}
void main ( )
{
	func(2, 2);
	func(2, 3);
	func(10, 20);
}
