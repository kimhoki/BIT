//ex04-05.c
#include <stdio.h>
void main ( )
{
	int iarr[4] ={10,20,30,40};
	int *ip = iarr;

	printf("%d %d\n", sizeof(iarr), sizeof(ip) );
}
