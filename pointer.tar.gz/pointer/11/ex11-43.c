//ex11-43.c
#include <stdio.h>
void main ( )
{
	int a = 10, b = 20;
	int F;

	F = a^b;
	
	printf("a = %d\n", F ^ b);
	printf("b = %d\n", F ^ a);
}
