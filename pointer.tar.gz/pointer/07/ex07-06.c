//ex07-06.c
#include <stdio.h>
struct _point
{
	int x;
	int y;
};
void main ( )
{
	struct _point s1 = {1,1};
	struct _point *sp = &s1;
	struct _point **spp = &sp;

	printf("%d %d %d\n", sizeof(s1), sizeof(sp), sizeof(spp));
	printf("%x %x %x %x\n",&s1, sp, spp, &spp);
	printf("%x %x %x %x\n",&s1+1, sp+1, spp+1, &spp+1);
}
