//ex11-31.c
#include <stdio.h>
#include <stdlib.h>
void main ( )
{
	int arr[100];
	int numCount[10] = {0};
	int i;

	for( i = 0 ; i < 100 ; i++)
	{
		arr[i] = rand() % 100;
	}
	for( i = 0 ; i < 100 ; i++)
	{
		if( (i+1) % 10 == 0 )
			puts("");
		else
			printf("%3d", arr[i]);
	}
	//////////////////////////////////
	puts("===========================");
	for( i = 0 ; i < 100 ; i++)
	{
		numCount[arr[i]/10]++;
	}
	for( i = 0 ; i < 10 ; i++)
	{
		printf("%d ~ %d������ ������ %d�� �Դϴ�.\n",
			i*10, (i+1)*10-1, numCount[i]);
	}
}

