//ex01-14.c
#include <stdio.h>
void main( )
{
	char c = 'A';

	printf("%x\n", &c); //12ff7c
	printf("%c %c \n", c, *&c);// A A
}