//ex13-15.c
#include <stdio.h>
int ustrlen(char *str)
{
	int i;
	for( i = 0 ; str[i] ; i++)
		;
	return i;
}
void main ( )
{
	char *str= "ABCDE";
	
	printf("%d\n", ustrlen(str));
}

