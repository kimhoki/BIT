//ex08-45.c
#include <stdio.h>
int Fibonacci(int n)
{
    return n <= 2 ? 1 : Fibonacci(n-2)+Fibonacci(n-1);
}
void main ( )
{
    printf("Fibonacci(5): %d\n", Fibonacci( 5 ));
}