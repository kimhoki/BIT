//ex08-27.c
#include <stdio.h>
void func(int *np)
{
	*np = 20;
}
void main ( )
{
	int n = 10;
	
	printf("%d\n", n);
	func( &n );
	printf("%d\n", n);
}

