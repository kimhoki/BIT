//ex07-07.c
#include <stdio.h>
struct _point
{
	int x;
	int y;
};
void main ( )
{
	struct _point sarr[2][2] = {{{0,0},{1,1}},{{2,2},{3,3}}};

	printf("(%d, %d) (%d, %d)\n", 
		sarr[0][0].x,sarr[0][0].y,sarr[0][1].x,sarr[0][1].y);
	printf("(%d, %d) (%d, %d)\n", 
		sarr[1][0].x,sarr[1][0].y,sarr[1][1].x,sarr[1][1].y);

	sarr[0][0].x = sarr[0][0].y = 2; 
	sarr[0][1].x = sarr[0][1].y = 1;
	sarr[1][0].x = sarr[1][0].y = 1; 
	sarr[1][1].x = sarr[1][1].y = 2;
	puts("==========");
	printf("(%d, %d) (%d, %d)\n", 
		sarr[0][0].x,sarr[0][0].y,sarr[0][1].x,sarr[0][1].y);
	printf("(%d, %d) (%d, %d)\n", 
		sarr[1][0].x,sarr[1][0].y,sarr[1][1].x,sarr[1][1].y);
}
