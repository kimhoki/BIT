//ex09-14.c
#include <stdio.h>
void main ( )
{
	int arr2[2][3] = {{10,20,30},{100,200,300}};
	int (*arr)[3];

	arr = arr2;

	printf("%d %d %d %d %d %d\n", arr[0][0], arr[0][1], arr[0][2],
		arr[1][0], arr[1][1], arr[1][2]);
}
