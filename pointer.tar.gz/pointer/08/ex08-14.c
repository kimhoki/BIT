//ex08-14.c
#include <stdio.h>
void func(auto int n1)
{
	auto int n2 = 20;

	printf("%d %d\n", n1, n2);
}
void main ( )
{
	auto int m = 10;
	func( m );
}
