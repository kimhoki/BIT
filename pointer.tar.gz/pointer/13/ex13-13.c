//ex13-13.c
#include <stdio.h>
void ustrcpy(char *str1, char *str2)
{
	int i;
	for( i = 0 ; str1[i] = str2[i] ; i++) // (str1[i]=str2[i]) != '\0'
		;
}
void main ( )
{
	char *str1= "ABCD";
	char temp[100];

	ustrcpy(temp, str1);
	
	puts(str1);
	puts(temp);
}
