//ex13-16.c
#include <stdio.h>
int ustrcmp(char *str1, char *str2)
{
	int i;
	
	for(i = 0 ; str1[i] || str2[i] ; i++)
	{
		if( str1[i] > str2[i])
			return 1;
		else if( str1[i] < str2[i] )
			return -1;
	}
	return 0;
}
void main ( )
{
	char *str1 = "ABCD";
	char *str2 = "ABCD";

	printf("%d\n", ustrcmp(str1, str2));
	if( ustrcmp(str1, str2) == 0 )
		puts("TRUE");
	else
		puts("FALSE");
}

