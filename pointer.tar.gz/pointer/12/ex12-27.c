//ex12-27.c
#include <stdio.h>
#include <string.h>
typedef int (*ARR3)[3][3];
typedef int (*ARR9)[9];

void ArrPrint(ARR9 arr)// int (*arr)[9]
{
	int i, j;

	for( i = 0 ; i < 9 ; i++)
	{
		for( j = 0 ; j < 9; j++)
			printf("%3d", arr[i][j]);
		puts("");
	}
	puts("=============================");
}
void main ( )
{
	int arr[9][9];
	ARR3 ap; // int (*ap)[3][3]
	int i,j;

	memset(arr,0, sizeof(int)*9*9);
	ArrPrint(arr);
	
	ap = (ARR3)arr;
	for( i = 0 ; i < 9 ; i++)
		for( j = 0 ; j < 3 ; j++)
			ap[i][1][j] = 1;
	ArrPrint(arr);

	for( i = 0 ; i < 9 ; i++)
		for( j = 0 ; j < 3 ; j++)
			ap[3][i][j] = 1;
	ArrPrint(arr);
	
	for( i = 3 ; i < 6 ; i++)
		for( j = 0 ; j < 3 ; j++)
			ap[i][1][j] = 3;
	ArrPrint(arr);
}

