//ex11-24.c
#include <stdio.h>
#include <stdlib.h>
void main ( )
{
	int i;
	srand( 1 );//srand( 2 );//srand( 3 );
	for( i = 0 ; i < 10 ; i++)
		printf("%d\n", rand());
}
