//ex08-09.c
#include <stdio.h>
void main ( )
{
	int sum;

	sum = 5 + 10;
	printf("%d\n", sum);
	sum = 10 + 20;
	printf("%d\n", sum);
	sum = 20 + 30;
	printf("%d\n", sum);
}

