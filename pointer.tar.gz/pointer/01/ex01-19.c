//ex01-19.c
#include <stdio.h>
void main ( )
{
	int n = 321; //0x141

	printf("%x %c\n", n, n);
}
