//ex10-11.c
#include <stdio.h>
void print(int n, ... )
{
	int i;
	int *ap = &n+1;

	for( i = 0; i < n ; i++)
		printf("%d ", ap[i]);
	printf("\n");
}
void main ( )
{
	int a =10, b =20, c =30;

	print( 1, a );
	print( 2, a, b );
	print( 3, a, b, c );
}
