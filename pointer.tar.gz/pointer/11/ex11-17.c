//ex11-17.c
#include <stdio.h>
void main ( )
{
	int n1 = 5, n2 = 2;
	double d;

	d = (double)n1 / n2; // (double)n1 / (double)n2

	printf("%lf", d);
}
