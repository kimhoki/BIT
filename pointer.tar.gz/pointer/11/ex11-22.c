//ex11-22.c
void main ( )
{
	int i;

	for( i = 0 ; i < 100 ; i++)
		printf("%2d", i / 10);
}
