//ex09-11.c
#include <stdio.h>
void main ( )
{
	int arr[3] = {10,20,30};

	printf("%d %d %d\n", arr[0], arr[1], arr[2]);
}
