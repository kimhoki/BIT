//ex08-33.c
#include <stdio.h>
void func(int m)
{
	printf("%d\n", m);
}
void main ( )
{
	int n = 10;
	func( n );
}
