//ex07-02.c
#include <stdio.h>
struct _point
{
	int x;
	int y;
};
void main ( )
{
	struct _point sarr[5]={1,1,2,2,3,3,4,4,5,5};
	//struct _point sarr[5]={{1,1},{2,2},{3,3},{4,4},{5,5}}

	printf("(%d, %d)\n", sarr[0].x, sarr[0].y);
	printf("(%d, %d)\n", sarr[1].x, sarr[1].y);
	printf("(%d, %d)\n", sarr[2].x, sarr[2].y);
	printf("(%d, %d)\n", sarr[3].x, sarr[3].y);
	printf("(%d, %d)\n", sarr[4].x, sarr[4].y);
}
