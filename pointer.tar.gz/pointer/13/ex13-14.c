//ex13-14.c
#include <stdio.h>
void ustrcat(char *str1, char *str2)
{
	int i,j;
	for( i = 0 ; str1[i] ; i++)//str1[i] != '\0'
		;
	for( j = 0 ; str1[i] = str2[j] ; i++, j++)
		;
}
void main ( )
{
	char *str1= "ABCD";
	char temp[100]="123";

	ustrcat(temp, str1);
	
	puts(str1);
	puts(temp);
}

