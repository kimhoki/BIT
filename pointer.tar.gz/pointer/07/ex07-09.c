//ex07-09.c
#include <stdio.h>
struct _point
{
	int x;
	int y;
};
void main ( )
{
	struct _point sarr[2][2] = {{{0,0},{1,1}},{{2,2},{3,3}}};
	struct _point (*ap)[2] = (struct _point (*)[2])sarr;

	printf("%x %x %x\n", ap, ap[0], ap[1]);
	printf("%x %x %x\n", ap+1, ap[0]+1, ap[1]+1);
	puts("===================");
	printf("(%d, %d) (%d, %d)\n", 
		ap[0][0].x,ap[0][0].y,ap[0][1].x,ap[0][1].y);
	printf("(%d, %d) (%d, %d)\n", 
		ap[1][0].x,ap[1][0].y,ap[1][1].x,ap[1][1].y);
}

