//ex12-09.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void main ( )
{
	int arr[10];
	int i;

	for( i = 0 ; i < 10 ; i++)
	{
		arr[i] = rand()%100;
		printf("%5d", arr[i]);
	}
	puts("");

	memset(arr,0, sizeof(int)*10);
	for( i = 0 ; i < 10 ; i++)
		printf("%5d", arr[i]);
	puts("");
}
