//ex11-28.c
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
void main ( )
{
	int i, n;

	srand( (unsigned) time(NULL));
	for( i = 0 ; i < 10 ; i++)
	{
		n = rand() % 26 + 65;
		printf("%c %d\n", n, n);
	}
}
