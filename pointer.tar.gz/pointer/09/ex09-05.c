//ex09-05.c
#include <stdio.h>
void main( )
{
	void (*fp)( );

	fp = main;
	printf("%x %x\n", main, fp);
}
