//ex11-26.c
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
void main ( )
{
	int i;
	for( i = 0 ; i < 10 ; i++)
	{
		srand( (unsigned) time(NULL));
		printf("%d\n", rand());
	}
}
