//ex11-42.c
#include <stdio.h>
void main ( )
{
	printf("& : %d\n", 0 & 1);
	printf("& : %d\n", 1 & 1);
	printf("& : %d\n", 2 & 3);
	printf("& : %d\n", 5 & 7);
	puts("==========");
	printf("| : %d\n", 0 | 1);
	printf("| : %d\n", 1 | 1);
	printf("| : %d\n", 2 | 3);
	printf("| : %d\n", 5 | 7);
	puts("==========");
	printf("^ : %d\n", 0 | 1);
	printf("^ : %d\n", 1 | 1);
	printf("^ : %d\n", 2 | 3);
	printf("^ : %d\n", 5 | 7);
	puts("==========");
	printf("~ : %d\n", ~0 );
	printf("~ : %d\n", ~1 );
	printf("~ : %d\n", ~2 );
	printf("~ : %d\n", ~-2 );
}
