//ex08-30.c
#include <stdio.h>
int* func( )
{
	static int n;
	scanf("%d", &n);

	return &n;
}
void main ( )
{
	int *ip;

	ip = func( );
	printf("%x %d\n", *ip);
}
