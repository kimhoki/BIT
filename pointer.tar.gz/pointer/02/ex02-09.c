//ex02-09.c
#include <stdio.h>
void main ( )
{
	char c = 'A';
	char *cp;
	char **cpp;

	cp = &c;
	cpp = &cp;

	printf("%x %x %x\n", c, cp, cpp);
	printf("%x %x %x\n", c+1, cp+1, cpp+1);
}
