//ex08-03.c
#include <stdio.h>
void main( )
{
	printf("%d\n", 1);
	printf("%d\n", 2);
	printf("%d\n", 3);
	printf("%d\n", 4);
	printf("%d\n", 5);
}

