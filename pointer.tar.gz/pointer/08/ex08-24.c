//ex08-24.c
#include <stdio.h>
void func( int (*ap)[3])//void func(int ap[][3])
{
	printf("%d %d %d %d %d %d\n",
		ap[0][0],ap[0][1],ap[0][2],ap[1][0],ap[1][1],ap[1][2]);
}
void main ( )
{
	int iarr[2][3] = {{10,20,30},{100,200,300}};
	func( iarr );
}
