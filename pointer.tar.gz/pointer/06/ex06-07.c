//ex06-07.c
#include <stdio.h>
struct _point
{
	double x;
	double y;
};
void main ( )
{
	struct _point p1={10,10};

	printf("%d %d %d\n",sizeof(p1), sizeof(p1.x), sizeof(p1.y));
}
