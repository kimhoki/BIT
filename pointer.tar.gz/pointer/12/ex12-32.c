//ex12-32.c
#include <stdio.h>
//////////// ���� �˰����� /////////////
void Sort(int list[], int size, int (*pred)(int,int))
{
	int i, j, min;

	for( i = 0 ; i < size-1 ; i++)
	{
		for( min = i, j = i+1 ; j < size ; j++)
		{
			if( pred(list[j], list[min]) )
				min = j;
		}
        {   //swap
		    int temp = list[i];
            list[i] = list[min];
            list[min] = temp;
        }
	}
}
////////// Ŭ���̾�Ʈ �� ��å �ݹ� �Լ� ////////////
int Less(int a, int b)
{
    return a < b;
}
int Greater(int a, int b)
{
    return a > b;
}
////////// Ŭ���̾�Ʈ //////////////
void main()
{
    int list[5] = {50, 20, 90, 10, 30};

    printf("����:%d %d %d %d %d\n", list[0], list[1], list[2], list[3], list[4]);
    Sort(list, 5, Less);
    printf("����:%d %d %d %d %d\n", list[0], list[1], list[2], list[3], list[4]);   
    Sort(list, 5, Greater);
    printf("����:%d %d %d %d %d\n", list[0], list[1], list[2], list[3], list[4]);
}