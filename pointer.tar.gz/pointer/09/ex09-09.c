//ex09-09.c
#include <stdio.h>
// ��ȣ����(callee)
int Add(int n1, int n2)
{
    printf("%d %d\n", n1, n2);
    return n1+n2;
}
// ȣ����(caller)
void main ( )
{
    printf("10+20 = %d\n", Add(10, 20));
}