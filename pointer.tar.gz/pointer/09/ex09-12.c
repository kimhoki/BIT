//ex09-12.c
#include <stdio.h>
void main ( )
{
	int arr[2][3] = {{10,20,30},{100,200,300}};

	printf("%d %d %d %d %d %d\n", arr[0][0], arr[0][1], arr[0][2],
		arr[1][0],arr[1][1],arr[1][2]);
}
